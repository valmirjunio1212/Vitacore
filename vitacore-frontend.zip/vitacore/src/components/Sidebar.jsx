import { NavLink } from 'react-router-dom';

const navItems = [
  { path: '/', label: 'Dashboard', icon: '⬡' },
  { path: '/registrar', label: 'Registrar', icon: '＋' },
  { path: '/historico', label: 'Histórico', icon: '◷' },
  { path: '/perfil', label: 'Perfil', icon: '◉' },
];

export default function Sidebar() {
  return (
    <aside style={{
      width: '220px',
      minHeight: '100vh',
      background: 'var(--bg-secondary)',
      borderRight: '1px solid var(--border)',
      display: 'flex',
      flexDirection: 'column',
      padding: '24px 0',
      flexShrink: 0,
    }}>
      {/* Logo */}
      <div style={{ padding: '0 24px 32px' }}>
        <h1 style={{
          fontFamily: 'var(--font-display)',
          fontSize: '22px',
          fontWeight: 800,
          letterSpacing: '-0.5px',
        }}>
          <span style={{ color: 'var(--accent-green)' }}>Vita</span>
          <span style={{ color: 'var(--text-primary)' }}>Core</span>
        </h1>
        <p style={{ fontSize: '11px', color: 'var(--text-secondary)', marginTop: '4px' }}>
          Saúde Preventiva
        </p>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1 }}>
        {navItems.map(item => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === '/'}
            style={({ isActive }) => ({
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              padding: '12px 24px',
              color: isActive ? 'var(--accent-green)' : 'var(--text-secondary)',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: 500,
              borderLeft: isActive ? '2px solid var(--accent-green)' : '2px solid transparent',
              background: isActive ? 'rgba(0,230,118,0.06)' : 'transparent',
              transition: 'all 0.15s',
            })}
          >
            <span style={{ fontSize: '16px' }}>{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>

      {/* User */}
      <div style={{
        padding: '16px 24px',
        borderTop: '1px solid var(--border)',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
      }}>
        <div style={{
          width: '32px', height: '32px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--accent-green), var(--accent-teal))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '13px', fontWeight: 700, color: '#000',
        }}>V</div>
        <div>
          <p style={{ fontSize: '13px', fontWeight: 500 }}>Valmir</p>
          <p style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>Usuário</p>
        </div>
      </div>
    </aside>
  );
}
