import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, PointElement, LineElement,
  Title, Tooltip, Legend, Filler,
} from 'chart.js';
import Card from '../components/Card';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend, Filler);

const labels = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'];

const pressaoData = {
  labels,
  datasets: [
    {
      label: 'Sistólica (mmHg)',
      data: [128, 125, 130, 122, 118, 120, 115],
      borderColor: '#ff7043',
      backgroundColor: 'rgba(255,112,67,0.12)',
      fill: true,
      tension: 0.4,
      pointBackgroundColor: '#ff7043',
    },
    {
      label: 'Diastólica (mmHg)',
      data: [82, 80, 85, 78, 76, 79, 75],
      borderColor: '#00bcd4',
      backgroundColor: 'rgba(0,188,212,0.08)',
      fill: true,
      tension: 0.4,
      pointBackgroundColor: '#00bcd4',
    },
  ],
};

const sonoData = {
  labels,
  datasets: [
    {
      label: 'Sono (horas)',
      data: [6.5, 7, 6, 8, 7.5, 9, 8],
      borderColor: '#7c4dff',
      backgroundColor: 'rgba(124,77,255,0.12)',
      fill: true,
      tension: 0.4,
      pointBackgroundColor: '#7c4dff',
    },
  ],
};

const aguaData = {
  labels,
  datasets: [
    {
      label: 'Hidratação (ml)',
      data: [1800, 2000, 1600, 2200, 2400, 2100, 1900],
      borderColor: '#00e676',
      backgroundColor: 'rgba(0,230,118,0.12)',
      fill: true,
      tension: 0.4,
      pointBackgroundColor: '#00e676',
    },
  ],
};

const chartOptions = (title) => ({
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { labels: { color: '#8b949e', font: { size: 12 } } },
    title: { display: false },
    tooltip: {
      backgroundColor: '#1c2128',
      borderColor: '#30363d',
      borderWidth: 1,
      titleColor: '#e6edf3',
      bodyColor: '#8b949e',
    },
  },
  scales: {
    x: { ticks: { color: '#8b949e' }, grid: { color: '#30363d' } },
    y: { ticks: { color: '#8b949e' }, grid: { color: '#30363d' } },
  },
});

const metricas = [
  { label: 'Pressão Atual', valor: '120/75', unidade: 'mmHg', cor: '#ff7043', icon: '♥' },
  { label: 'Sono Ontem', valor: '8.0', unidade: 'horas', cor: '#7c4dff', icon: '◑' },
  { label: 'Água Hoje', valor: '1.900', unidade: 'ml', cor: '#00e676', icon: '◈' },
  { label: 'Glicose', valor: '96', unidade: 'mg/dL', cor: '#00bcd4', icon: '⬡' },
];

export default function Dashboard() {
  return (
    <div style={{ flex: 1, padding: '32px', overflowY: 'auto' }}>
      {/* Header */}
      <div style={{ marginBottom: '32px' }}>
        <p style={{ fontSize: '12px', color: 'var(--text-secondary)', letterSpacing: '2px', textTransform: 'uppercase', marginBottom: '6px' }}>
          Visão Geral
        </p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '28px', fontWeight: 800 }}>
          Dashboard de Saúde
        </h2>
        <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '14px' }}>
          Últimos 7 dias — Sábado, 19 de Abril de 2026
        </p>
      </div>

      {/* Métricas cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
        {metricas.map(m => (
          <Card key={m.label}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <p style={{ fontSize: '11px', color: 'var(--text-secondary)', marginBottom: '8px', letterSpacing: '1px', textTransform: 'uppercase' }}>{m.label}</p>
                <p style={{ fontFamily: 'var(--font-display)', fontSize: '26px', fontWeight: 700, color: m.cor }}>
                  {m.valor}
                </p>
                <p style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '2px' }}>{m.unidade}</p>
              </div>
              <span style={{ fontSize: '22px', color: m.cor, opacity: 0.7 }}>{m.icon}</span>
            </div>
          </Card>
        ))}
      </div>

      {/* Gráficos */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
        <Card>
          <p style={{ fontSize: '13px', fontWeight: 600, marginBottom: '16px', color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
            PRESSÃO ARTERIAL — 7 DIAS
          </p>
          <div style={{ height: '200px' }}>
            <Line data={pressaoData} options={chartOptions('Pressão')} />
          </div>
        </Card>
        <Card>
          <p style={{ fontSize: '13px', fontWeight: 600, marginBottom: '16px', color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
            QUALIDADE DO SONO — 7 DIAS
          </p>
          <div style={{ height: '200px' }}>
            <Line data={sonoData} options={chartOptions('Sono')} />
          </div>
        </Card>
      </div>

      <Card>
        <p style={{ fontSize: '13px', fontWeight: 600, marginBottom: '16px', color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
          HIDRATAÇÃO DIÁRIA — 7 DIAS
        </p>
        <div style={{ height: '180px' }}>
          <Line data={aguaData} options={chartOptions('Água')} />
        </div>
      </Card>

      {/* Anotações recentes */}
      <Card style={{ marginTop: '16px' }}>
        <p style={{ fontSize: '13px', fontWeight: 600, marginBottom: '16px', color: 'var(--text-secondary)', letterSpacing: '0.5px' }}>
          ANOTAÇÕES RECENTES
        </p>
        {[
          { data: '19/04', texto: 'Dia tranquilo. Dormi bem, pressão estável.', cor: '#00e676' },
          { data: '18/04', texto: 'Senti leve tontura ao acordar. Bebi pouca água.', cor: '#ff7043' },
          { data: '17/04', texto: 'Atividade física. Pressão subiu levemente.', cor: '#00bcd4' },
        ].map((a, i) => (
          <div key={i} style={{
            display: 'flex', gap: '12px', alignItems: 'flex-start',
            paddingBottom: '12px', marginBottom: '12px',
            borderBottom: i < 2 ? '1px solid var(--border)' : 'none',
          }}>
            <span style={{ fontSize: '11px', color: a.cor, fontWeight: 600, whiteSpace: 'nowrap', marginTop: '2px' }}>{a.data}</span>
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.5 }}>{a.texto}</p>
          </div>
        ))}
      </Card>
    </div>
  );
}
