import Card from '../components/Card';

const registros = [
  { data: '19/04/2026', hora: '08:15', indicador: 'Pressão', valor: '120/75 mmHg', cor: '#ff7043', anotacao: 'Dia tranquilo. Sem sintomas.' },
  { data: '19/04/2026', hora: '07:00', indicador: 'Sono', valor: '8h', cor: '#7c4dff', anotacao: 'Dormi bem. Sem interrupções.' },
  { data: '18/04/2026', hora: '22:00', indicador: 'Hidratação', valor: '1.900 ml', cor: '#00e676', anotacao: 'Dia corrido, bebi pouca água.' },
  { data: '18/04/2026', hora: '07:30', indicador: 'Glicose', valor: '98 mg/dL', cor: '#00bcd4', anotacao: 'Medido em jejum. Normal.' },
  { data: '17/04/2026', hora: '09:00', indicador: 'Pressão', valor: '125/80 mmHg', cor: '#ff7043', anotacao: 'Atividade física mais cedo.' },
  { data: '17/04/2026', hora: '22:30', indicador: 'Hidratação', valor: '2.400 ml', cor: '#00e676', anotacao: 'Muita atividade. Hidratação boa.' },
  { data: '16/04/2026', hora: '08:00', indicador: 'Peso', valor: '74.5 kg', cor: '#ffa726', anotacao: '' },
];

export default function Historico() {
  return (
    <div style={{ flex: 1, padding: '32px', overflowY: 'auto' }}>
      <div style={{ marginBottom: '32px' }}>
        <p style={{ fontSize: '12px', color: 'var(--text-secondary)', letterSpacing: '2px', textTransform: 'uppercase', marginBottom: '6px' }}>
          Registros
        </p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '28px', fontWeight: 800 }}>
          Histórico de Dados
        </h2>
        <p style={{ color: 'var(--text-secondary)', marginTop: '4px', fontSize: '14px' }}>
          Todos os registros salvos
        </p>
      </div>

      {/* Filtros */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '24px', flexWrap: 'wrap' }}>
        {['Todos', 'Pressão', 'Sono', 'Hidratação', 'Glicose', 'Peso'].map(f => (
          <button key={f} style={{
            padding: '6px 14px', borderRadius: '6px',
            border: f === 'Todos' ? '1px solid var(--accent-green)' : '1px solid var(--border)',
            background: f === 'Todos' ? 'rgba(0,230,118,0.1)' : 'var(--bg-card)',
            color: f === 'Todos' ? 'var(--accent-green)' : 'var(--text-secondary)',
            fontSize: '12px', cursor: 'pointer', fontFamily: 'var(--font-body)',
          }}>{f}</button>
        ))}
      </div>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
          <thead>
            <tr style={{ background: 'var(--bg-secondary)', borderBottom: '1px solid var(--border)' }}>
              {['Data', 'Hora', 'Indicador', 'Valor', 'Anotação'].map(h => (
                <th key={h} style={{ padding: '12px 16px', textAlign: 'left', color: 'var(--text-secondary)', fontWeight: 600, letterSpacing: '0.5px', fontSize: '11px', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {registros.map((r, i) => (
              <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                <td style={{ padding: '12px 16px', color: 'var(--text-secondary)' }}>{r.data}</td>
                <td style={{ padding: '12px 16px', color: 'var(--text-secondary)' }}>{r.hora}</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    padding: '3px 10px', borderRadius: '4px',
                    background: `${r.cor}18`, color: r.cor,
                    fontSize: '11px', fontWeight: 600,
                  }}>{r.indicador}</span>
                </td>
                <td style={{ padding: '12px 16px', fontFamily: 'var(--font-display)', fontWeight: 700, color: r.cor }}>{r.valor}</td>
                <td style={{ padding: '12px 16px', color: 'var(--text-secondary)', maxWidth: '200px' }}>
                  {r.anotacao || <span style={{ opacity: 0.4 }}>—</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
