import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const inputStyle = {
  background: '#161b22',
  border: '1px solid #30363d',
  borderRadius: '8px',
  padding: '12px 16px',
  color: '#e6edf3',
  fontSize: '14px',
  outline: 'none',
  width: '100%',
  fontFamily: 'DM Sans, sans-serif',
};

export default function Login() {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    navigate('/');
  };

  return (
    <div style={{
      minHeight: '100vh', width: '100%',
      display: 'flex',
      background: '#0d1117',
    }}>
      {/* Painel esquerdo decorativo */}
      <div style={{
        flex: 1,
        background: 'linear-gradient(135deg, #0d1117 0%, #161b22 60%, #1c2128 100%)',
        display: 'flex', flexDirection: 'column',
        justifyContent: 'center', alignItems: 'center',
        padding: '60px',
        borderRight: '1px solid #30363d',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Decoração circular */}
        <div style={{
          position: 'absolute', width: '400px', height: '400px',
          border: '1px solid rgba(0,230,118,0.15)', borderRadius: '50%',
          top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
        }} />
        <div style={{
          position: 'absolute', width: '250px', height: '250px',
          border: '1px solid rgba(0,188,212,0.1)', borderRadius: '50%',
          top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
        }} />

        <h1 style={{
          fontFamily: 'Syne, sans-serif', fontSize: '48px', fontWeight: 800,
          letterSpacing: '-1px', textAlign: 'center', position: 'relative',
        }}>
          <span style={{ color: '#00e676' }}>Vita</span>
          <span style={{ color: '#e6edf3' }}>Core</span>
        </h1>
        <p style={{ color: '#8b949e', marginTop: '12px', fontSize: '15px', textAlign: 'center', position: 'relative', maxWidth: '300px', lineHeight: 1.6 }}>
          Centralize seus dados de saúde. Visualize sua evolução. Cuide-se melhor.
        </p>

        {/* Métricas fake */}
        <div style={{ display: 'flex', gap: '16px', marginTop: '48px', position: 'relative' }}>
          {[
            { label: 'Pressão', valor: '120/75', cor: '#ff7043' },
            { label: 'Sono', valor: '8h', cor: '#7c4dff' },
            { label: 'Água', valor: '2L', cor: '#00e676' },
          ].map(m => (
            <div key={m.label} style={{
              background: '#1c2128', border: '1px solid #30363d',
              borderRadius: '10px', padding: '14px 18px', textAlign: 'center',
            }}>
              <p style={{ fontFamily: 'Syne, sans-serif', fontSize: '20px', fontWeight: 700, color: m.cor }}>{m.valor}</p>
              <p style={{ fontSize: '11px', color: '#8b949e', marginTop: '4px' }}>{m.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Formulário */}
      <div style={{
        width: '420px', flexShrink: 0,
        display: 'flex', flexDirection: 'column',
        justifyContent: 'center', padding: '60px 48px',
      }}>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: '24px', fontWeight: 800, marginBottom: '6px' }}>
          Entrar na conta
        </h2>
        <p style={{ color: '#8b949e', fontSize: '14px', marginBottom: '32px' }}>
          Acesse seu painel de saúde
        </p>

        <form onSubmit={handleLogin}>
          <div style={{ marginBottom: '16px' }}>
            <label style={{ fontSize: '12px', color: '#8b949e', display: 'block', marginBottom: '6px' }}>E-mail</label>
            <input style={inputStyle} type="email" placeholder="seu@email.com" value={email} onChange={e => setEmail(e.target.value)} required />
          </div>
          <div style={{ marginBottom: '24px' }}>
            <label style={{ fontSize: '12px', color: '#8b949e', display: 'block', marginBottom: '6px' }}>Senha</label>
            <input style={inputStyle} type="password" placeholder="••••••••" value={senha} onChange={e => setSenha(e.target.value)} required />
          </div>
          <button type="submit" style={{
            width: '100%', padding: '13px',
            background: '#00e676', border: 'none', borderRadius: '8px',
            color: '#000', fontWeight: 700, fontSize: '14px',
            cursor: 'pointer', fontFamily: 'DM Sans, sans-serif',
            letterSpacing: '0.5px',
          }}>
            ENTRAR
          </button>
        </form>

        <p style={{ marginTop: '24px', fontSize: '13px', color: '#8b949e', textAlign: 'center' }}>
          Não tem conta?{' '}
          <span style={{ color: '#00e676', cursor: 'pointer' }}>Cadastre-se</span>
        </p>
      </div>
    </div>
  );
}
