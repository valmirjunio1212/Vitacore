import Card from '../components/Card';

const inputStyle = {
  background: 'var(--bg-secondary)',
  border: '1px solid var(--border)',
  borderRadius: '8px',
  padding: '10px 14px',
  color: 'var(--text-primary)',
  fontSize: '14px',
  outline: 'none',
  width: '100%',
  fontFamily: 'var(--font-body)',
};

export default function Perfil() {
  return (
    <div style={{ flex: 1, padding: '32px', overflowY: 'auto' }}>
      <div style={{ marginBottom: '32px' }}>
        <p style={{ fontSize: '12px', color: 'var(--text-secondary)', letterSpacing: '2px', textTransform: 'uppercase', marginBottom: '6px' }}>
          Conta
        </p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '28px', fontWeight: 800 }}>
          Perfil do Usuário
        </h2>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
        <Card>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '20px', letterSpacing: '0.5px', fontWeight: 600 }}>
            DADOS PESSOAIS
          </p>
          <div style={{ marginBottom: '16px' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>Nome Completo</label>
            <input style={inputStyle} defaultValue="Valmir Júnio de Oliveira Avelar" />
          </div>
          <div style={{ marginBottom: '16px' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>E-mail</label>
            <input style={inputStyle} defaultValue="valmir@vitacore.app" />
          </div>
          <div style={{ marginBottom: '16px' }}>
            <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>Data de Nascimento</label>
            <input style={inputStyle} type="date" defaultValue="1998-03-15" />
          </div>
          <button style={{
            padding: '10px 20px', background: 'var(--accent-green)', border: 'none',
            borderRadius: '8px', color: '#000', fontWeight: 700, fontSize: '13px',
            cursor: 'pointer', fontFamily: 'var(--font-body)',
          }}>
            SALVAR ALTERAÇÕES
          </button>
        </Card>

        <Card>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '20px', letterSpacing: '0.5px', fontWeight: 600 }}>
            CONFIGURAÇÕES DE LEMBRETES
          </p>
          {[
            { label: 'Lembrete de Pressão', hora: '08:00', ativo: true },
            { label: 'Lembrete de Hidratação', hora: '12:00', ativo: true },
            { label: 'Lembrete de Sono', hora: '22:00', ativo: false },
          ].map((l, i) => (
            <div key={i} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '12px 0',
              borderBottom: i < 2 ? '1px solid var(--border)' : 'none',
            }}>
              <div>
                <p style={{ fontSize: '13px', fontWeight: 500 }}>{l.label}</p>
                <p style={{ fontSize: '11px', color: 'var(--text-secondary)', marginTop: '2px' }}>{l.hora}</p>
              </div>
              <div style={{
                width: '40px', height: '22px', borderRadius: '11px',
                background: l.ativo ? 'var(--accent-green)' : 'var(--border)',
                position: 'relative', cursor: 'pointer',
              }}>
                <div style={{
                  width: '16px', height: '16px', borderRadius: '50%',
                  background: '#fff',
                  position: 'absolute',
                  top: '3px',
                  left: l.ativo ? '21px' : '3px',
                  transition: 'left 0.2s',
                }} />
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}
