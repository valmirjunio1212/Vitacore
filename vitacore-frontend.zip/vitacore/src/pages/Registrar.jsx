import { useState } from 'react';
import Card from '../components/Card';

const indicadores = [
  { id: 'pressao', label: 'Pressão Arterial', icon: '♥', cor: '#ff7043', duplo: true, unidade: 'mmHg', placeholder1: 'Sistólica', placeholder2: 'Diastólica' },
  { id: 'sono', label: 'Qualidade do Sono', icon: '◑', cor: '#7c4dff', duplo: false, unidade: 'horas', placeholder1: 'Horas dormidas' },
  { id: 'agua', label: 'Hidratação', icon: '◈', cor: '#00e676', duplo: false, unidade: 'ml', placeholder1: 'Quantidade em ml' },
  { id: 'glicose', label: 'Glicemia', icon: '⬡', cor: '#00bcd4', duplo: false, unidade: 'mg/dL', placeholder1: 'Valor em mg/dL' },
  { id: 'peso', label: 'Peso Corporal', icon: '◻', cor: '#ffa726', duplo: false, unidade: 'kg', placeholder1: 'Peso em kg' },
];

const inputStyle = {
  background: 'var(--bg-secondary)',
  border: '1px solid var(--border)',
  borderRadius: '8px',
  padding: '10px 14px',
  color: 'var(--text-primary)',
  fontSize: '14px',
  outline: 'none',
  width: '100%',
  fontFamily: 'var(--font-body)',
};

export default function Registrar() {
  const [selecionado, setSelecionado] = useState('pressao');
  const [valor1, setValor1] = useState('');
  const [valor2, setValor2] = useState('');
  const [anotacao, setAnotacao] = useState('');
  const [sucesso, setSucesso] = useState(false);

  const ind = indicadores.find(i => i.id === selecionado);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSucesso(true);
    setValor1(''); setValor2(''); setAnotacao('');
    setTimeout(() => setSucesso(false), 3000);
  };

  return (
    <div style={{ flex: 1, padding: '32px', overflowY: 'auto' }}>
      <div style={{ marginBottom: '32px' }}>
        <p style={{ fontSize: '12px', color: 'var(--text-secondary)', letterSpacing: '2px', textTransform: 'uppercase', marginBottom: '6px' }}>
          Novo Registro
        </p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '28px', fontWeight: 800 }}>
          Registrar Indicador
        </h2>
      </div>

      {/* Seletor de indicador */}
      <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', marginBottom: '24px' }}>
        {indicadores.map(ind => (
          <button
            key={ind.id}
            onClick={() => setSelecionado(ind.id)}
            style={{
              display: 'flex', alignItems: 'center', gap: '8px',
              padding: '10px 18px',
              borderRadius: '8px',
              border: selecionado === ind.id ? `1.5px solid ${ind.cor}` : '1.5px solid var(--border)',
              background: selecionado === ind.id ? `${ind.cor}15` : 'var(--bg-card)',
              color: selecionado === ind.id ? ind.cor : 'var(--text-secondary)',
              cursor: 'pointer',
              fontSize: '13px', fontWeight: 500,
              fontFamily: 'var(--font-body)',
              transition: 'all 0.15s',
            }}
          >
            <span>{ind.icon}</span> {ind.label}
          </button>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
        {/* Formulário */}
        <Card>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '20px', letterSpacing: '0.5px', fontWeight: 600 }}>
            DADOS DO REGISTRO
          </p>

          {sucesso && (
            <div style={{
              background: 'rgba(0,230,118,0.1)', border: '1px solid var(--accent-green)',
              borderRadius: '8px', padding: '12px 16px', marginBottom: '20px',
              color: 'var(--accent-green)', fontSize: '13px', fontWeight: 500,
            }}>
              ✓ Registro salvo com sucesso!
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                {ind.placeholder1} ({ind.unidade})
              </label>
              <input
                style={inputStyle}
                type="number"
                placeholder={`Ex: ${ind.id === 'pressao' ? '120' : ind.id === 'sono' ? '7.5' : ind.id === 'agua' ? '2000' : ind.id === 'glicose' ? '96' : '75'}`}
                value={valor1}
                onChange={e => setValor1(e.target.value)}
                required
              />
            </div>

            {ind.duplo && (
              <div style={{ marginBottom: '16px' }}>
                <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                  {ind.placeholder2} ({ind.unidade})
                </label>
                <input
                  style={inputStyle}
                  type="number"
                  placeholder="Ex: 80"
                  value={valor2}
                  onChange={e => setValor2(e.target.value)}
                  required
                />
              </div>
            )}

            <div style={{ marginBottom: '16px' }}>
              <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Data e Hora
              </label>
              <input
                style={inputStyle}
                type="datetime-local"
                defaultValue="2026-04-19T08:00"
              />
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{ fontSize: '12px', color: 'var(--text-secondary)', display: 'block', marginBottom: '6px' }}>
                Mini Anotação Diária (opcional)
              </label>
              <textarea
                style={{ ...inputStyle, minHeight: '80px', resize: 'vertical' }}
                placeholder="Como você está se sentindo hoje? Algo relevante ocorreu?"
                value={anotacao}
                onChange={e => setAnotacao(e.target.value)}
              />
            </div>

            <button
              type="submit"
              style={{
                width: '100%',
                padding: '12px',
                background: ind.cor,
                border: 'none',
                borderRadius: '8px',
                color: '#000',
                fontWeight: 700,
                fontSize: '14px',
                cursor: 'pointer',
                fontFamily: 'var(--font-body)',
                letterSpacing: '0.5px',
              }}
            >
              SALVAR REGISTRO
            </button>
          </form>
        </Card>

        {/* Dicas */}
        <Card>
          <p style={{ fontSize: '13px', color: 'var(--text-secondary)', marginBottom: '20px', letterSpacing: '0.5px', fontWeight: 600 }}>
            SOBRE ESTE INDICADOR
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
            <span style={{ fontSize: '32px', color: ind.cor }}>{ind.icon}</span>
            <div>
              <p style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: 700 }}>{ind.label}</p>
              <p style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>Unidade: {ind.unidade}</p>
            </div>
          </div>
          {selecionado === 'pressao' && (
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              A pressão normal é abaixo de 120/80 mmHg. Meça sempre no mesmo horário, sentado e em repouso por 5 minutos. Registre os dois valores: sistólica (maior) e diastólica (menor).
            </p>
          )}
          {selecionado === 'sono' && (
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              Adultos precisam de 7 a 9 horas por noite. Registre o tempo total dormido, considerando desde que apagou a luz até acordar definitivamente.
            </p>
          )}
          {selecionado === 'agua' && (
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              A recomendação geral é de 2 litros (2000 ml) por dia. Esse valor varia conforme peso e atividade física. Registre o total consumido ao longo do dia.
            </p>
          )}
          {selecionado === 'glicose' && (
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              Glicemia em jejum normal: abaixo de 100 mg/dL. Registre se foi medido em jejum ou após refeição. Esse dado é crucial para acompanhamento de diabetes.
            </p>
          )}
          {selecionado === 'peso' && (
            <p style={{ fontSize: '13px', color: 'var(--text-secondary)', lineHeight: 1.7 }}>
              Pese-se sempre no mesmo horário, preferencialmente pela manhã em jejum. Registre com precisão de 1 casa decimal para melhor acompanhamento de evolução.
            </p>
          )}
        </Card>
      </div>
    </div>
  );
}
